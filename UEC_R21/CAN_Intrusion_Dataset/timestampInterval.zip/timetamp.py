import re
import matplotlib.pyplot as plt

def temps_moyen_entre_baquettes(dataprocessed):
    with open(dataprocessed, 'r') as f:
        lignes = f.readlines()

    timestamps = []

    for ligne in lignes:
        match = re.search(r'Timestamp:\s+([\d.]+)', ligne)
        if match:
            timestamp = float(match.group(1))
            timestamps.append(timestamp)

    differences = [timestamps[i+1] - timestamps[i] for i in range(len(timestamps)-1)]

    temps_moyen = sum(differences) / len(differences) if differences else 0

    return temps_moyen

dataprocessed = "dataprocessed.txt"
resultat = temps_moyen_entre_baquettes(dataprocessed)
print(f"Le temps moyen entre les baquettes est de {resultat} secondes.")
import matplotlib
differences = [timestamps[i+1] - timestamps[i] for i in range(len(timestamps)-1)]

temps_moyen = sum(differences) / len(differences) if differences else 0
# Tracer le graphique
plt.plot(differences, label='Différences entre les timestamps')
plt.xlabel('Index')
plt.ylabel('Différence entre les timestamps (secondes)')
plt.legend()
plt.show()
 


dataprocessed = "dataprocessed.txt"
resultat = temps_moyen_entre_baquettes(nom_fichier)
print(f"Le temps moyen entre les baquettes est de {resultat} secondes.")
