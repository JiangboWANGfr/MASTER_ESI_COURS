from collections import defaultdict
import re
import os
import matplotlib.pyplot as plt
from getfilepath import getFilesFromDirectory, getOutputFilePath
# the raw data directory path
directory_path = "./raw_dataset"
output_file_directoy = "./Dataprocessed/getIDreceiveInterval/txt"
file_extension = "_IDreceiveInterval"


# Function to parse a line and extract timestamp and ID

def parse_line(line):
    # Split the line into parts
    parts = line.split()
    # Extract timestamp and ID
    timestamp = float(parts[1])
    id_hex = parts[3]
    return timestamp, id_hex


def getIDtimeinterval(input_file, output_file):

    # Read the file and parse all lines
    timestamps_by_id = defaultdict(list)

    with open(input_file, 'r') as file:
        lines = file.readlines()
        for line in lines[0:50000]:
            timestamp, id_hex = parse_line(line)
            timestamps_by_id[id_hex].append(timestamp)

    # Calculate time intervals for each ID
    time_intervals_by_id = {id_hex: [t - s for s, t in zip(ts[:-1], ts[1:])]
                            for id_hex, ts in timestamps_by_id.items() if len(ts) > 1}
    return time_intervals_by_id


def plotIDreceiveInterval(time_intervals_by_id, output_file):
    # Extract the time intervals for ID '0153'
    time_intervals_0316 = time_intervals_by_id['0153']

    # Plot the time intervals for ID '0153'
    plt.figure(figsize=(12, 6))
    plt.plot(time_intervals_0316, marker='o')
    plt.title('Time Intervals for ID 0153')
    plt.xlabel('Occurrence Index')
    plt.ylabel('Time Interval (seconds)')
    plt.grid(True)
    plt.show()


def dataProcess():
    # Define the input and output file paths
    input_files_path = getFilesFromDirectory(directory_path)
    # Change to your desired output file name
    for input_file in input_files_path:
        # get the output file path
        output_file_path = getOutputFilePath(
            input_file, output_file_directoy, file_extension)
        # save the result to output file
        IDtimeinterval = getIDtimeinterval(input_file, output_file_path)
        # plot the result
        plotIDreceiveInterval(IDtimeinterval, output_file_path)


if __name__ == "__main__":
    dataProcess()
    print("Data processing finished!")
