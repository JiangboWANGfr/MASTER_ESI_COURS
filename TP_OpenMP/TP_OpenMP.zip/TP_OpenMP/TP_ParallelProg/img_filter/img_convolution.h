#ifndef IMG_CONVOLUTION_H_GUARD
#define IMG_CONVOLUTION_H_GUARD
void  convolution(image_t* img, float coefficient);
#endif // IMG_CONVOLUTION_H_GUARD
